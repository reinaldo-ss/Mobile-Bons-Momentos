package com.bonsmomentos.entregador.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.bonsmomentos.entregador.App;
import com.bonsmomentos.entregador.databinding.ActivityLoginBinding;
import com.bonsmomentos.entregador.sync.SyncScheduler;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private LoginViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (((App) getApplication()).getSession().estaLogado()) {
            irParaPrincipal();
            return;
        }

        viewModel = new ViewModelProvider(this).get(LoginViewModel.class);

        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnEntrar.setOnClickListener(v ->
                viewModel.entrar(
                        binding.etCpf.getText().toString(),
                        binding.etSenha.getText().toString()));

        viewModel.getEstado().observe(this, estado -> {
            boolean carregando = estado.tipo == LoginState.Tipo.CARREGANDO;
            binding.btnEntrar.setEnabled(!carregando);
            binding.btnEntrar.setText(carregando ? "Entrando..." : "Entrar");
            binding.tvErro.setVisibility(
                    estado.tipo == LoginState.Tipo.ERRO ? View.VISIBLE : View.GONE);

            switch (estado.tipo) {
                case ERRO:
                    binding.tvErro.setText(estado.mensagem);
                    break;
                case SUCESSO:
                    SyncScheduler.agendarPeriodico(this);
                    SyncScheduler.sincronizarAgora(this);
                    irParaPrincipal();
                    break;
                default:
                    break;
            }
        });
    }

    private void irParaPrincipal() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
