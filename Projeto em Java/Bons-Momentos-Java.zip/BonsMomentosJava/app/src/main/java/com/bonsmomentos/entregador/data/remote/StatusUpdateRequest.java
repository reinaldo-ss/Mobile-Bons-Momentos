package com.bonsmomentos.entregador.data.remote;

public class StatusUpdateRequest {
    public final String status;

    public StatusUpdateRequest(String status) {
        this.status = status;
    }
}
