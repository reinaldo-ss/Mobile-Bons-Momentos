package com.bonsmomentos.entregador.data;

public enum SyncResult { SUCESSO, FALHA_REDE, NAO_AUTORIZADO }
