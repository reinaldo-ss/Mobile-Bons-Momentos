package com.bonsmomentos.entregador.data.remote;

import com.bonsmomentos.entregador.data.local.PedidoEntity;
import com.bonsmomentos.entregador.data.local.StatusPedido;
import com.google.gson.annotations.SerializedName;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PedidoTabelaDto {

    private static final Pattern CEP = Pattern.compile("[0-9]{5}-?[0-9]{3}");

    public long id;
    @SerializedName("id_motoboy")
    public Long idMotoboy;
    @SerializedName("endereco_entrega")
    public String enderecoEntrega;
    @SerializedName("opcao_pagamento")
    public String opcaoPagamento;
    public String status;
    public ReceitaJoinDto receitas;
    public UsuarioJoinDto usuarios;

    public PedidoEntity paraEntity() {
        String end = enderecoEntrega != null ? enderecoEntrega : "";

        Matcher m = CEP.matcher(end);
        String cepExtraido;
        if (m.find()) {
            cepExtraido = m.group();
        } else if (usuarios != null && usuarios.cep != null) {
            cepExtraido = usuarios.cep;
        } else {
            cepExtraido = "";
        }

        String produto = (receitas != null && receitas.nome != null) ? receitas.nome : "";
        String pagamento = opcaoPagamento != null ? opcaoPagamento : "";
        String statusNormalizado = status != null
                ? status.trim().toUpperCase(Locale.ROOT).replace(' ', '_')
                : StatusPedido.PENDENTE;

        return new PedidoEntity(
                id, produto, pagamento, cepExtraido, end, statusNormalizado,
                false, System.currentTimeMillis());
    }
}
