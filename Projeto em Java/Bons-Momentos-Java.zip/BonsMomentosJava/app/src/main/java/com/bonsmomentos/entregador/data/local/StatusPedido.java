package com.bonsmomentos.entregador.data.local;

public final class StatusPedido {
    public static final String PENDENTE = "PENDENTE";
    public static final String EM_ROTA = "EM_ROTA";
    public static final String ENTREGUE = "ENTREGUE";

    private StatusPedido() {}
}
