package com.bonsmomentos.entregador.data.local;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {PedidoEntity.class}, version = 2, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract PedidoDao pedidoDao();

    private static volatile AppDatabase instancia;

    public static AppDatabase get(Context context) {
        if (instancia == null) {
            synchronized (AppDatabase.class) {
                if (instancia == null) {
                    instancia = Room.databaseBuilder(
                                    context.getApplicationContext(), AppDatabase.class, "bonsmomentos.db")
                            // Fase de desenvolvimento: se a estrutura mudar, recria o banco local.
                            // (Antes de publicar, trocar por migrações reais.)
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return instancia;
    }
}
