package com.bonsmomentos.entregador.sync;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public final class SyncScheduler {
    private static final String PERIODICO = "sync_periodico";
    private static final String IMEDIATO = "sync_imediato";

    private SyncScheduler() {}

    private static Constraints comRede() {
        return new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
    }

    /** Sincroniza a cada 15 min (mínimo do WorkManager) quando houver internet. */
    public static void agendarPeriodico(Context ctx) {
        PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(SyncWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(comRede())
                .build();
        WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork(PERIODICO, ExistingPeriodicWorkPolicy.KEEP, req);
    }

    /** Dispara assim que houver rede — se estiver offline, fica na fila até voltar. */
    public static void sincronizarAgora(Context ctx) {
        OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(SyncWorker.class)
                .setConstraints(comRede())
                .build();
        WorkManager.getInstance(ctx)
                .enqueueUniqueWork(IMEDIATO, ExistingWorkPolicy.APPEND_OR_REPLACE, req);
    }

    public static void cancelarTudo(Context ctx) {
        WorkManager wm = WorkManager.getInstance(ctx);
        wm.cancelUniqueWork(PERIODICO);
        wm.cancelUniqueWork(IMEDIATO);
    }
}
