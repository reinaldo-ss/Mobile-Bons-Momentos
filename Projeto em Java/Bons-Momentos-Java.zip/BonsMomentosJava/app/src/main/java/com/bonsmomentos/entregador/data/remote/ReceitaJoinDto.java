package com.bonsmomentos.entregador.data.remote;

public class ReceitaJoinDto {
    public String nome;
}
