package com.bonsmomentos.entregador.sync;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.bonsmomentos.entregador.App;
import com.bonsmomentos.entregador.data.Repository;
import com.bonsmomentos.entregador.data.SyncResult;

/** O WorkManager já executa doWork() em uma thread de segundo plano. */
public class SyncWorker extends Worker {

    public SyncWorker(@NonNull Context ctx, @NonNull WorkerParameters params) {
        super(ctx, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Repository repo = ((App) getApplicationContext()).getRepository();
        SyncResult resultado = repo.sincronizar();
        switch (resultado) {
            case SUCESSO:
                return Result.success();
            case FALHA_REDE:
                return Result.retry();      // tenta de novo com backoff
            default:                        // NAO_AUTORIZADO
                return Result.failure();
        }
    }
}
