package com.bonsmomentos.entregador.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bonsmomentos.entregador.App;
import com.bonsmomentos.entregador.R;
import com.bonsmomentos.entregador.data.Repository;
import com.bonsmomentos.entregador.data.SyncResult;
import com.bonsmomentos.entregador.databinding.ActivityMainBinding;
import com.bonsmomentos.entregador.sync.SyncScheduler;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private App app;
    private Repository repo;
    private PedidoAdapter adapter;

    private String rotuloSync = "";
    private int qtdPendentes = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        app = (App) getApplication();
        repo = app.getRepository();

        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.bm_creme));
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        adapter = new PedidoAdapter(pedido ->
                app.getIo().execute(() -> {
                    repo.marcarEntregue(pedido.id);              // salva no aparelho na hora
                    SyncScheduler.sincronizarAgora(this);        // envia quando houver rede
                }));

        binding.tvOla.setText("Bem-Vindo, " + app.getSession().nome());
        binding.rvPedidos.setLayoutManager(new LinearLayoutManager(this));
        binding.rvPedidos.setAdapter(adapter);
        binding.swipe.setColorSchemeResources(R.color.bm_terracota);
        binding.swipe.setOnRefreshListener(this::sincronizar);
        binding.btnSair.setOnClickListener(v -> sair());

        // A lista sempre vem do banco local (funciona offline).
        // LiveData só notifica enquanto a tela está visível (STARTED).
        repo.getPedidos().observe(this, lista -> {
            adapter.submitList(lista);
            binding.tvVazio.setVisibility(lista.isEmpty() ? View.VISIBLE : View.GONE);
        });
        repo.getQtdPendentes().observe(this, qtd -> {
            qtdPendentes = qtd != null ? qtd : 0;
            atualizarInfo();
        });

        atualizarRotuloSync();
    }

    @Override
    protected void onStart() {
        super.onStart();
        sincronizar();
    }

    private void sincronizar() {
        binding.swipe.setRefreshing(true);
        app.getIo().execute(() -> {
            SyncResult resultado = repo.sincronizar();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                switch (resultado) {
                    case NAO_AUTORIZADO:
                        sair();
                        break;
                    case FALHA_REDE:
                        rotuloSync = "Offline — dados salvos no aparelho";
                        atualizarInfo();
                        break;
                    case SUCESSO:
                        atualizarRotuloSync();
                        break;
                }
                binding.swipe.setRefreshing(false);
            });
        });
    }

    private void atualizarRotuloSync() {
        long t = app.getSession().ultimaSync();
        rotuloSync = (t == 0L)
                ? "Ainda não sincronizado"
                : "Sincronizado " + DateUtils.getRelativeTimeSpanString(t);
        atualizarInfo();
    }

    private void atualizarInfo() {
        String pendentes = qtdPendentes > 0 ? " • " + qtdPendentes + " aguardando envio" : "";
        binding.tvSyncInfo.setText(rotuloSync + pendentes);
    }

    private void sair() {
        SyncScheduler.cancelarTudo(this);
        app.getIo().execute(() -> {
            repo.logout();
            runOnUiThread(() -> {
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                finish();
            });
        });
    }
}
