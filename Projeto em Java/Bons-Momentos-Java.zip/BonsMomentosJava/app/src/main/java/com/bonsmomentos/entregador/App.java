package com.bonsmomentos.entregador;

import android.app.Application;

import com.bonsmomentos.entregador.data.Repository;
import com.bonsmomentos.entregador.data.SessionManager;
import com.bonsmomentos.entregador.data.local.AppDatabase;
import com.bonsmomentos.entregador.data.remote.ApiClient;
import com.bonsmomentos.entregador.data.remote.ApiService;
import com.bonsmomentos.entregador.sync.SyncScheduler;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Container simples de dependências (singletons criados sob demanda). */
public class App extends Application {

    private SessionManager session;
    private AppDatabase database;
    private ApiService api;
    private Repository repository;

    /** Pool para trabalho de rede/banco fora da thread principal. */
    private final ExecutorService io = Executors.newFixedThreadPool(4);

    public synchronized SessionManager getSession() {
        if (session == null) session = new SessionManager(this);
        return session;
    }

    public synchronized AppDatabase getDatabase() {
        if (database == null) database = AppDatabase.get(this);
        return database;
    }

    public synchronized ApiService getApi() {
        if (api == null) api = ApiClient.create(getSession());
        return api;
    }

    public synchronized Repository getRepository() {
        if (repository == null) {
            repository = new Repository(getApi(), getDatabase().pedidoDao(), getSession());
        }
        return repository;
    }

    public ExecutorService getIo() {
        return io;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (getSession().estaLogado()) SyncScheduler.agendarPeriodico(this);
    }
}
