package com.bonsmomentos.entregador.data;

/** Resultado do login (substitui o Result&lt;Unit&gt; do Kotlin). */
public final class LoginResultado {
    public final boolean sucesso;
    public final String mensagem;

    private LoginResultado(boolean sucesso, String mensagem) {
        this.sucesso = sucesso;
        this.mensagem = mensagem;
    }

    public static LoginResultado ok() { return new LoginResultado(true, null); }
    public static LoginResultado erro(String mensagem) { return new LoginResultado(false, mensagem); }
}
