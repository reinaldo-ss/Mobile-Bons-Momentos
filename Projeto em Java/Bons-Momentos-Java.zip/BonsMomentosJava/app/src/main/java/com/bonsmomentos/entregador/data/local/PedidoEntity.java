package com.bonsmomentos.entregador.data.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.util.Objects;

@Entity(tableName = "pedidos")
public class PedidoEntity {

    @PrimaryKey
    public final long id;
    @NonNull public final String produto;
    @NonNull public final String pagamento;
    @NonNull public final String cep;
    @NonNull public final String endereco;
    @NonNull public final String status;
    /** true = alteração feita offline que ainda não foi enviada ao servidor */
    public final boolean syncPendente;
    public final long atualizadoEm;

    /** Construtor usado pelo Room (todos os campos). */
    public PedidoEntity(long id,
                        @NonNull String produto,
                        @NonNull String pagamento,
                        @NonNull String cep,
                        @NonNull String endereco,
                        @NonNull String status,
                        boolean syncPendente,
                        long atualizadoEm) {
        this.id = id;
        this.produto = produto;
        this.pagamento = pagamento;
        this.cep = cep;
        this.endereco = endereco;
        this.status = status;
        this.syncPendente = syncPendente;
        this.atualizadoEm = atualizadoEm;
    }

    /** Conveniência: syncPendente = false e atualizadoEm = agora. */
    @Ignore
    public PedidoEntity(long id,
                        @NonNull String produto,
                        @NonNull String pagamento,
                        @NonNull String cep,
                        @NonNull String endereco,
                        @NonNull String status) {
        this(id, produto, pagamento, cep, endereco, status, false, System.currentTimeMillis());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PedidoEntity)) return false;
        PedidoEntity p = (PedidoEntity) o;
        return id == p.id
                && syncPendente == p.syncPendente
                && atualizadoEm == p.atualizadoEm
                && produto.equals(p.produto)
                && pagamento.equals(p.pagamento)
                && cep.equals(p.cep)
                && endereco.equals(p.endereco)
                && status.equals(p.status);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, produto, pagamento, cep, endereco, status, syncPendente, atualizadoEm);
    }
}
