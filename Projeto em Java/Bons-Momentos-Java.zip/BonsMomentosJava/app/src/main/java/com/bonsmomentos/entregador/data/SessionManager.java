package com.bonsmomentos.entregador.data;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.IOException;
import java.security.GeneralSecurityException;

public class SessionManager {

    private static final String K_TOKEN = "token";
    private static final String K_REFRESH = "refresh_token";
    private static final String K_ID = "id";
    private static final String K_NOME = "nome";
    private static final String K_ULTIMA_SYNC = "ultima_sync";

    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            prefs = EncryptedSharedPreferences.create(
                    context,
                    "sessao_segura",
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (GeneralSecurityException | IOException e) {
            throw new IllegalStateException("Não foi possível abrir o armazenamento seguro", e);
        }
    }

    public void salvar(String token, String refreshToken, long id, String nome) {
        prefs.edit()
                .putString(K_TOKEN, token)
                .putString(K_REFRESH, refreshToken)
                .putLong(K_ID, id)
                .putString(K_NOME, nome)
                .apply();
    }

    public String token() { return prefs.getString(K_TOKEN, null); }
    public long id() { return prefs.getLong(K_ID, 0L); }
    public String nome() { return prefs.getString(K_NOME, ""); }
    public boolean estaLogado() { return id() > 0L; }

    public void registrarSync(long timestamp) {
        prefs.edit().putLong(K_ULTIMA_SYNC, timestamp).apply();
    }

    public long ultimaSync() { return prefs.getLong(K_ULTIMA_SYNC, 0L); }

    public void limpar() { prefs.edit().clear().apply(); }
}
