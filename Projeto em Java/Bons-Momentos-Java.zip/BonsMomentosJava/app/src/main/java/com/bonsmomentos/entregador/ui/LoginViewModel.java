package com.bonsmomentos.entregador.ui;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.bonsmomentos.entregador.App;
import com.bonsmomentos.entregador.data.LoginResultado;
import com.bonsmomentos.entregador.data.Repository;

public class LoginViewModel extends AndroidViewModel {

    private final App app;
    private final MutableLiveData<LoginState> estado = new MutableLiveData<>(LoginState.ocioso());

    public LoginViewModel(@NonNull Application application) {
        super(application);
        this.app = (App) application;
    }

    public LiveData<LoginState> getEstado() {
        return estado;
    }

    /** Deve ser chamado na thread principal. */
    public void entrar(String cpf, String senha) {
        final String cpfLimpo = Repository.soDigitos(cpf);
        if (cpfLimpo.length() < 10 || cpfLimpo.length() > 11) {
            estado.setValue(LoginState.erro("Informe um CPF válido"));
            return;
        }
        if (senha.isEmpty()) {
            estado.setValue(LoginState.erro("Informe a senha"));
            return;
        }
        estado.setValue(LoginState.carregando());

        final Repository repo = app.getRepository();
        app.getIo().execute(() -> {
            LoginResultado r = repo.login(cpfLimpo, senha);
            if (r.sucesso) {
                estado.postValue(LoginState.sucesso());
            } else {
                estado.postValue(LoginState.erro(r.mensagem != null ? r.mensagem : "Falha no login"));
            }
        });
    }
}
