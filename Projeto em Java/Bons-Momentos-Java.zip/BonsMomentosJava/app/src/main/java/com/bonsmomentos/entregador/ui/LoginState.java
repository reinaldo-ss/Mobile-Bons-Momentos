package com.bonsmomentos.entregador.ui;

/** Estado da tela de login (substitui a sealed class do Kotlin). */
public final class LoginState {

    public enum Tipo { OCIOSO, CARREGANDO, SUCESSO, ERRO }

    public final Tipo tipo;
    public final String mensagem;

    private LoginState(Tipo tipo, String mensagem) {
        this.tipo = tipo;
        this.mensagem = mensagem;
    }

    public static LoginState ocioso() { return new LoginState(Tipo.OCIOSO, null); }
    public static LoginState carregando() { return new LoginState(Tipo.CARREGANDO, null); }
    public static LoginState sucesso() { return new LoginState(Tipo.SUCESSO, null); }
    public static LoginState erro(String mensagem) { return new LoginState(Tipo.ERRO, mensagem); }
}
