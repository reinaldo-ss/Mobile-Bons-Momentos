package com.bonsmomentos.entregador.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bonsmomentos.entregador.R;
import com.bonsmomentos.entregador.data.local.PedidoEntity;
import com.bonsmomentos.entregador.databinding.ItemPedidoBinding;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Lista de pedidos em formato "acordeão": toca no topo para abrir/fechar os detalhes. */
public class PedidoAdapter extends ListAdapter<PedidoEntity, PedidoAdapter.VH> {

    public interface OnConcluirListener {
        void aoConcluir(PedidoEntity pedido);
    }

    private static final DiffUtil.ItemCallback<PedidoEntity> DIFF =
            new DiffUtil.ItemCallback<PedidoEntity>() {
                @Override
                public boolean areItemsTheSame(@NonNull PedidoEntity a, @NonNull PedidoEntity b) {
                    return a.id == b.id;
                }

                @Override
                public boolean areContentsTheSame(@NonNull PedidoEntity a, @NonNull PedidoEntity b) {
                    return a.equals(b);
                }
            };

    private final OnConcluirListener aoConcluir;

    /** Guarda quais pedidos estão abertos (sobrevive à reciclagem das linhas). */
    private final Set<Long> abertos = new HashSet<>();

    public PedidoAdapter(OnConcluirListener aoConcluir) {
        super(DIFF);
        this.aoConcluir = aoConcluir;
    }

    static class VH extends RecyclerView.ViewHolder {
        final ItemPedidoBinding b;

        VH(ItemPedidoBinding b) {
            super(b.getRoot());
            this.b = b;
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(ItemPedidoBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        final PedidoEntity p = getItem(position);
        final ItemPedidoBinding b = holder.b;
        Context ctx = b.getRoot().getContext();

        b.tvTitulo.setText("Pedido - " + String.format(Locale.ROOT, "%02d", p.id));
        b.tvProduto.setText(linha(ctx, "Produto:", p.produto));
        b.tvPagamento.setText(linha(ctx, "Pagamento:", p.pagamento));
        b.tvCep.setText(linha(ctx, "CEP:", p.cep));
        b.tvEndereco.setText(linha(ctx, "Endereço:", p.endereco));

        aplicarEstado(b, abertos.contains(p.id));

        b.llTopo.setOnClickListener(v -> {
            boolean abrir = !abertos.contains(p.id);
            if (abrir) abertos.add(p.id); else abertos.remove(p.id);
            TransitionManager.beginDelayedTransition((ViewGroup) b.getRoot());
            aplicarEstado(b, abrir);
        });
        b.btnConcluir.setOnClickListener(v -> aoConcluir.aoConcluir(p));
    }

    private void aplicarEstado(ItemPedidoBinding b, boolean aberto) {
        b.llDetalhes.setVisibility(aberto ? View.VISIBLE : View.GONE);
        b.ivSeta.setRotation(aberto ? 180f : 0f);
    }

    /** "Rótulo:" em negrito marrom + valor em cinza (igual ao front). */
    private CharSequence linha(Context ctx, String rotulo, String valor) {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        sb.append(rotulo);
        int fim = sb.length();
        sb.setSpan(new ForegroundColorSpan(ContextCompat.getColor(ctx, R.color.bm_marrom_escuro)),
                0, fim, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new StyleSpan(Typeface.BOLD), 0, fim, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.append(' ');
        sb.append(valor == null || valor.trim().isEmpty() ? "—" : valor);
        return sb;
    }
}
