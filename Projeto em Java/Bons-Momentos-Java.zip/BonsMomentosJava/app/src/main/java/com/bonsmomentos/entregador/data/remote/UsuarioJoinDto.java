package com.bonsmomentos.entregador.data.remote;

public class UsuarioJoinDto {
    public String cep;
}
