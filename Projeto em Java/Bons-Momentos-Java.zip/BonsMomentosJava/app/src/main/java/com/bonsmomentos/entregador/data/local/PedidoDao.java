package com.bonsmomentos.entregador.data.local;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

/**
 * Os métodos que retornam LiveData são observáveis na thread principal.
 * Todos os outros acessam o banco de forma síncrona e DEVEM ser chamados
 * fora da thread principal (use o executor do {@code App}).
 */
@Dao
public interface PedidoDao {

    /** Tela "Pedidos disponíveis": tudo que ainda não foi entregue. */
    @Query("SELECT * FROM pedidos WHERE status != 'ENTREGUE' ORDER BY id")
    LiveData<List<PedidoEntity>> observarDisponiveis();

    @Query("SELECT COUNT(*) FROM pedidos WHERE syncPendente = 1")
    LiveData<Integer> observarQtdPendentes();

    @Query("SELECT COUNT(*) FROM pedidos")
    int contar();

    @Query("SELECT * FROM pedidos WHERE syncPendente = 1")
    List<PedidoEntity> pendentes();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void upsertAll(List<PedidoEntity> lista);

    @Query("UPDATE pedidos SET status = :status, syncPendente = 1, atualizadoEm = :ts WHERE id = :id")
    void atualizarStatusLocal(long id, String status, long ts);

    /** Só limpa a flag se o registro não mudou desde o envio (evita perder edição concorrente). */
    @Query("UPDATE pedidos SET syncPendente = 0 WHERE id = :id AND atualizadoEm = :ts")
    void marcarSincronizada(long id, long ts);

    @Query("DELETE FROM pedidos WHERE syncPendente = 0 AND id NOT IN (:idsRemotos)")
    void removerAusentes(List<Long> idsRemotos);

    @Query("DELETE FROM pedidos")
    void limparTudo();
}
