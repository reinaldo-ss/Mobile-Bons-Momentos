package com.bonsmomentos.entregador.data;

import androidx.lifecycle.LiveData;

import com.bonsmomentos.entregador.BuildConfig;
import com.bonsmomentos.entregador.data.local.PedidoDao;
import com.bonsmomentos.entregador.data.local.PedidoEntity;
import com.bonsmomentos.entregador.data.local.StatusPedido;
import com.bonsmomentos.entregador.data.remote.ApiService;
import com.bonsmomentos.entregador.data.remote.MotoboyDto;
import com.bonsmomentos.entregador.data.remote.PedidoTabelaDto;
import com.bonsmomentos.entregador.data.remote.StatusUpdateRequest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import okhttp3.ResponseBody;
import retrofit2.HttpException;
import retrofit2.Response;

/**
 * Atenção: {@link #login}, {@link #marcarEntregue}, {@link #sincronizar} e {@link #logout}
 * são BLOQUEANTES (rede/banco). Chame-os sempre fora da thread principal.
 */
public class Repository {

    private final ApiService api;
    private final PedidoDao dao;
    private final SessionManager session;
    private final Object lockSync = new Object();

    public Repository(ApiService api, PedidoDao dao, SessionManager session) {
        this.api = api;
        this.dao = dao;
        this.session = session;
    }

    public LiveData<List<PedidoEntity>> getPedidos() {
        return dao.observarDisponiveis();
    }

    public LiveData<Integer> getQtdPendentes() {
        return dao.observarQtdPendentes();
    }

    public static String soDigitos(String s) {
        StringBuilder sb = new StringBuilder();
        if (s != null) {
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (Character.isDigit(c)) sb.append(c);
            }
        }
        return sb.toString();
    }

    /** Equivalente ao comportamento das funções suspend do Retrofit: erro HTTP vira exceção. */
    private static <T> T corpo(Response<T> resp) throws IOException {
        if (!resp.isSuccessful()) throw new HttpException(resp);
        return resp.body();
    }

    public LoginResultado login(String cpf, String senha) {
        if (BuildConfig.MODO_DEMO) {
            session.salvar("token-demo", null, 1L, "Entregador Demo");
            return LoginResultado.ok();
        }
        try {
            String cpfLimpo = soDigitos(cpf);
            List<MotoboyDto> motoboys = corpo(api.listarMotoboys().execute());

            if (motoboys == null || motoboys.isEmpty()) {
                session.limpar();
                return LoginResultado.erro(
                        "O banco retornou 0 motoboys. Verifique se a RLS está ativa na tabela motoboy.");
            }

            MotoboyDto peloCpf = null;
            for (MotoboyDto m : motoboys) {
                if (soDigitos(m.cpf).equals(cpfLimpo)) {
                    peloCpf = m;
                    break;
                }
            }

            if (peloCpf == null) {
                session.limpar();
                StringBuilder lista = new StringBuilder();
                for (int i = 0; i < motoboys.size(); i++) {
                    if (i > 0) lista.append(", ");
                    String c = motoboys.get(i).cpf;
                    lista.append(c != null ? c : "");
                }
                return LoginResultado.erro("CPF não encontrado. CPFs no banco: [" + lista + "]");
            }

            String senhaBanco = peloCpf.senha != null ? peloCpf.senha : "";
            if (!senhaBanco.trim().equals(senha.trim())) {
                session.limpar();
                return LoginResultado.erro(
                        "CPF encontrado (" + peloCpf.nome + "), mas a senha digitada não confere.");
            }

            session.salvar("sessao-" + peloCpf.id, null, peloCpf.id,
                    peloCpf.nome != null ? peloCpf.nome : "Entregador");
            return LoginResultado.ok();
        } catch (HttpException e) {
            session.limpar();
            String erroBody = "";
            try {
                Response<?> r = e.response();
                ResponseBody eb = r != null ? r.errorBody() : null;
                if (eb != null) {
                    String s = eb.string();
                    erroBody = s.length() > 120 ? s.substring(0, 120) : s;
                }
            } catch (IOException ignorado) {
                // sem corpo de erro para exibir
            }
            return LoginResultado.erro("Erro HTTP " + e.code() + ": " + erroBody);
        } catch (IOException e) {
            session.limpar();
            return LoginResultado.erro("Sem conexão com o servidor");
        }
    }

    public void marcarEntregue(long id) {
        dao.atualizarStatusLocal(id, StatusPedido.ENTREGUE, System.currentTimeMillis());
    }

    public SyncResult sincronizar() {
        synchronized (lockSync) {   // só uma sincronização por vez (antigo Mutex)
            if (BuildConfig.MODO_DEMO) return sincronizarDemo();
            long idMotoboy = session.id();
            if (idMotoboy <= 0L) return SyncResult.NAO_AUTORIZADO;

            try {
                for (PedidoEntity e : dao.pendentes()) {
                    Response<Void> resp = api.atualizarStatusPedido(
                            "eq." + e.id, new StatusUpdateRequest("Entregue")).execute();
                    int codigo = resp.code();
                    if (resp.isSuccessful()) {
                        dao.marcarSincronizada(e.id, e.atualizadoEm);
                    } else if (codigo == 401) {
                        return SyncResult.NAO_AUTORIZADO;
                    } else if (codigo >= 400 && codigo <= 499 && codigo != 408 && codigo != 429) {
                        dao.marcarSincronizada(e.id, e.atualizadoEm);
                    } else {
                        return SyncResult.FALHA_REDE;
                    }
                }

                List<PedidoTabelaDto> todosDoMotoboy =
                        corpo(api.buscarPedidosDoMotoboy("eq." + idMotoboy).execute());
                if (todosDoMotoboy == null) todosDoMotoboy = new ArrayList<>();

                List<PedidoTabelaDto> disponiveis = new ArrayList<>();
                for (PedidoTabelaDto p : todosDoMotoboy) {
                    if (p.status != null && p.status.trim().equalsIgnoreCase("Saiu para entrega")) {
                        disponiveis.add(p);
                    }
                }

                Set<Long> aindaPendentes = new HashSet<>();
                for (PedidoEntity p : dao.pendentes()) aindaPendentes.add(p.id);

                List<PedidoEntity> paraSalvar = new ArrayList<>();
                List<Long> idsRemotos = new ArrayList<>();
                for (PedidoTabelaDto p : disponiveis) {
                    idsRemotos.add(p.id);
                    if (!aindaPendentes.contains(p.id)) paraSalvar.add(p.paraEntity());
                }

                dao.upsertAll(paraSalvar);
                dao.removerAusentes(idsRemotos);
                session.registrarSync(System.currentTimeMillis());
                return SyncResult.SUCESSO;
            } catch (HttpException e) {
                return e.code() == 401 ? SyncResult.NAO_AUTORIZADO : SyncResult.FALHA_REDE;
            } catch (IOException e) {
                return SyncResult.FALHA_REDE;
            }
        }
    }

    private SyncResult sincronizarDemo() {
        for (PedidoEntity e : dao.pendentes()) dao.marcarSincronizada(e.id, e.atualizadoEm);
        if (dao.contar() == 0) dao.upsertAll(pedidosDemo());
        session.registrarSync(System.currentTimeMillis());
        return SyncResult.SUCESSO;
    }

    private List<PedidoEntity> pedidosDemo() {
        return Arrays.asList(
                new PedidoEntity(1L, "Bolo de Chocolate", "PIX", "01001-000",
                        "Rua Santos Domingos, Nº 219 - Centro, São Paulo", StatusPedido.PENDENTE),
                new PedidoEntity(2L, "Torta de Morango", "Dinheiro", "04567-010",
                        "Av. Exemplo, Nº 111 - Vila Nova, São Paulo", StatusPedido.PENDENTE),
                new PedidoEntity(3L, "Caixa de Brigadeiros (12 un.)", "Cartão", "02020-020",
                        "Rua das Flores, Nº 45 - Jardim Bonito, São Paulo", StatusPedido.PENDENTE)
        );
    }

    public void logout() {
        session.limpar();
        dao.limparTudo();
    }
}
