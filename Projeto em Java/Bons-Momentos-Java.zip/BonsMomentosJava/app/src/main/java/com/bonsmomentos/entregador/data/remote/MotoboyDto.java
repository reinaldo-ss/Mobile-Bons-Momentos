package com.bonsmomentos.entregador.data.remote;

public class MotoboyDto {
    public long id;
    public String nome;
    public String cpf;
    public String senha;
}
