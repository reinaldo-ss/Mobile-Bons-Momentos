package com.bonsmomentos.entregador.data.remote;

import com.bonsmomentos.entregador.BuildConfig;
import com.bonsmomentos.entregador.data.SessionManager;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class ApiClient {

    private ApiClient() {}

    public static ApiService create(SessionManager session) {
        HttpLoggingInterceptor log = new HttpLoggingInterceptor();
        log.redactHeader("Authorization");
        log.redactHeader("apikey");
        log.setLevel(BuildConfig.DEBUG
                ? HttpLoggingInterceptor.Level.BASIC
                : HttpLoggingInterceptor.Level.NONE);

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(log)
                .addInterceptor(chain -> {
                    Request.Builder req = chain.request().newBuilder()
                            .header("apikey", BuildConfig.SUPABASE_KEY);
                    // Só envia Authorization se for uma chave JWT (começa com "eyJ")
                    if (BuildConfig.SUPABASE_KEY.startsWith("eyJ")) {
                        req.header("Authorization", "Bearer " + BuildConfig.SUPABASE_KEY);
                    }
                    return chain.proceed(req.build());
                })
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();

        // Se a BASE_URL ainda for o texto de exemplo (ou estiver sem https://),
        // o Retrofit derrubaria o app. Usamos um endereço de mentira: as chamadas
        // simplesmente falham com "sem conexão" em vez de fechar o app.
        String base = BuildConfig.BASE_URL.trim();
        if (!base.startsWith("http://") && !base.startsWith("https://")) {
            base = "https://servidor-nao-configurado.invalid/";
        }
        if (!base.endsWith("/")) {
            base = base + "/";
        }

        return new Retrofit.Builder()
                .baseUrl(base)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiService.class);
    }
}
