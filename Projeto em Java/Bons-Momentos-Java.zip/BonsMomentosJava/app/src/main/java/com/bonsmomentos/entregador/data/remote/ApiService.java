package com.bonsmomentos.entregador.data.remote;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.PATCH;
import retrofit2.http.Query;

/** Todas as chamadas são {@code Call}: use {@code execute()} fora da thread principal. */
public interface ApiService {

    @GET("rest/v1/motoboy?select=id,nome,cpf,senha")
    Call<List<MotoboyDto>> listarMotoboys();

    @GET("rest/v1/pedidos?select=id,id_motoboy,endereco_entrega,opcao_pagamento,status,receitas(nome),usuarios(cep)")
    Call<List<PedidoTabelaDto>> buscarPedidosDoMotoboy(
            @Query("id_motoboy") String filtroMotoboy
    );

    @PATCH("rest/v1/pedidos")
    Call<Void> atualizarStatusPedido(
            @Query("id") String filtroId,
            @Body StatusUpdateRequest body
    );
}
