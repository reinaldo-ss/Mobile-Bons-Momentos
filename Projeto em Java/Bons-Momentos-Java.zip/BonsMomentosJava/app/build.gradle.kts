plugins {
    id("com.android.application")
}

android {
    namespace = "com.bonsmomentos.entregador"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.bonsmomentos.entregador"
        minSdk = 26          // Android 8.0 (API 26)
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // Supabase (URL do projeto e chave PÚBLICA "publishable" — pode ficar no app).
        // NUNCA coloque aqui a chave "service_role" / "secret".
        buildConfigField("String", "BASE_URL", "\"https://gfsedzumavjktbshgphz.supabase.co/\"")
        buildConfigField("String", "SUPABASE_KEY", "\"sb_publishable_MIBEi8eKGwQzD67KssF9-Q_aCagR95Q\"")

        // MODO DEMONSTRAÇÃO: true = app funciona SEM internet/servidor (login aceita
        // qualquer email/senha e mostra pedidos de exemplo). false = usa o Supabase.
        buildConfigField("boolean", "MODO_DEMO", "false")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        // Java 8 é suficiente (lambdas, etc.) e totalmente suportado a partir da API 26.
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel:2.7.0")
    implementation("androidx.lifecycle:lifecycle-livedata:2.7.0")

    // Persistência local (Room com annotation processor em Java)
    implementation("androidx.room:room-runtime:2.6.1")
    annotationProcessor("androidx.room:room-compiler:2.6.1")

    // Sincronização em segundo plano
    implementation("androidx.work:work-runtime:2.9.0")

    // API REST
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

    // Armazenamento seguro do token
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
}
